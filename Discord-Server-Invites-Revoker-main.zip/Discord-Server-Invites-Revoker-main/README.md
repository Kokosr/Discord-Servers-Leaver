# Discord-Server-Invites-Revoker
A simple script to revoke all Discord server invites. You can whitelist users and Bot will not revoke their invites.

# How to Use

1. Input your Discord Bot token in main.py
2. Start the script.
3. Use !start or !revoke command on your Discord server
4. The Bot will begin revoking invite links of your server.
